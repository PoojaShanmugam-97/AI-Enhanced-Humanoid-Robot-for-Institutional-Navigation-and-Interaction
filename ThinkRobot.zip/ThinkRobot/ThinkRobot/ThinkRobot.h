#ifndef ThinkRobot_h
#define ThinkRobot_h

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <ArduinoJson.h>

class ThinkRobot {
  public:
    ThinkRobot(int chipSelect, int rxPin, int txPin, int baud);
    void begin(const char* ssid, const char* password);
    void handleClient();
  private:
    WebServer server;
    HardwareSerial MySerial;
    const char* validKey = "z6g0G8lnFC";
    const int BUFF = 1024;
    int rows = 50;
    const int cols = 19;
    int data[50][19];
    void handleRoot();
    void Reader(String name);
    void Sender();
};

#endif
