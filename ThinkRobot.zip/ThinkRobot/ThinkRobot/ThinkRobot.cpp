#include "ThinkRobot.h"

ThinkRobot::ThinkRobot(int chipSelect, int rxPin, int txPin, int baud) : MySerial(1) {
  MySerial.begin(baud, SERIAL_8N1, rxPin, txPin);
  SD.begin(chipSelect);
}

void ThinkRobot::begin(const char* ssid, const char* password) {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
  }
  MDNS.begin("svce.robot");
  server.on("/", std::bind(&ThinkRobot::handleRoot, this));
  server.begin();
}

void ThinkRobot::handleClient() {
  server.handleClient();
}

void ThinkRobot::handleRoot() {
  if (server.hasArg("action") && server.hasArg("key")) {
    String action = server.arg("action");
    String key = server.arg("key");
    if (action != "" && key == validKey) {
      Reader(action);
      String response;
      response.concat("<html><head><title>SVCE KA ROBOT</title></head><body><h4>Data stored in the array:</h4></br>");
      response.concat("</br>");
      for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
          response.concat(data[i][j]);
          response.concat("  ");
        }
        response.concat("</br></body></html>");
      }
      server.send(200, "text/html", response);
    } else {
      server.send(403, "text/plain", "Forbidden: Invalid User or Key");
    }
  } else {
    server.send(400, "text/plain", "Bad Request: User or Key not provided");
  }
}

void ThinkRobot::Reader(String name) {
  name.concat(".csv");
  File file = SD.open("/" + name);
  if (!file) {
    Serial.println("Failed to open " + name);
    server.send(200, "text/plain", "Failed to open file");
    return;
  }
  int row = 0;
  while (file.available() && row < rows) {
    String line = file.readStringUntil('\n');
    line.trim();
    int col = 0;
    int pos = 0;
    while (col < cols && pos < line.length()) {
      int commaPos = line.indexOf(',', pos);
      if (commaPos == -1) {
        commaPos = line.length();
      }
      String value = line.substring(pos, commaPos);
      data[row][col] = value.toInt();
      pos = commaPos + 1;
      col++;
      if (row == 0) {
        rows = data[0][0] + 1;
      }
    }
    row++;
  }
  file.close();
}
